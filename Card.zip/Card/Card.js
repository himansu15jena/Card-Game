var app = angular.module('myApp',[]);
app.controller('Ctrl', ['$scope', function($scope){
    $scope.obj=[["Clubs", "Diamonds", "Hearts", "Spades" ],["2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace" ]]

    var suits=$scope.suit.length;
    var ranks=$scope.rank.length;
    var t=suits*ranks;

}]

$scope.shuffle = function(o){

    for(var j, x, i = o.length; i; j = Math.floor(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
    return o;
};
}]);

deck = function() {
    _.each(suits, function(suit){
        _.each(ranks, function(rank){
            cards.push( {
                suit: suit,
                value: rank
            });
        });
    });
},

    draw = function() {
        shuffled = _.shuffle(cards);
        var card = 0;
        _.times(numCards, function(c) {
            _.times(players.length, function(p) {
                hands[p].push(shuffled[card]);
                card++;
                showCard(p,c);
            });
        });
    },
    showCard = function(p,c) {
        console.log(hands[p][c]);
        $('.player-' + p + ' .cards')
            .append(
                $('<div>' )
                    .addClass('card suit-' + hands[p][c].suit)
                    .append(
                        $('<div>' )
                            .addClass('rank')
                            .html( hands[p][c].value )
                    )
                    .append(
                        $('<div>' )
                            .addClass('suit')
                            .html( hands[p][c].suit )
                    )
            )
    }

init();
deal();